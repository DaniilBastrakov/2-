﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Бастраков
{
    public partial class Список_клиентов : Form
    {
        public Список_клиентов()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            using (var db = new Агентство_недвижемостиEntities())
            {
                var s = db.Клиент.Select(a => new
                {
                    a.ID_клиента,
                    a.Фамилия,
                    a.Имя,
                    a.Отчество,
                    a.Номер_телефона,
                    a.Электронная_почта,
                    a.Логин,
                    a.Недвижимость,
                });
                s = s.Where(a => a.ID_клиента <1);
                dataGridView1.DataSource = s.ToList();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 список_Клиентов = new Form1();
            список_Клиентов.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Добавление_клиента список_Клиентов = new Добавление_клиента();
            список_Клиентов.Show();
            this.Hide();

        }
    }
}
