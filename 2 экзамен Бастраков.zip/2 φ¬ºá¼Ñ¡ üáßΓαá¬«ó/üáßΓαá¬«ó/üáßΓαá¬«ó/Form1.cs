﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Бастраков
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var db = new Агентство_недвижемостиEntities())
            {
                var resultsearch = db.Авторизация.FirstOrDefault(item => item.Логин == textBox1.Text && item.Пароль == textBox2.Text);

                if(resultsearch != null)
                {
                    MessageBox.Show("Успешный вход," + " " + resultsearch.Логин);
                    Список_клиентов список_Клиентов = new Список_клиентов();
                    список_Клиентов.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Неудачный вход.Проверьте правильность написания данных!!!");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (var db = new Агентство_недвижемостиEntities())
            {
                var a = new Авторизация();
                a.Логин = textBox1.Text;
                a.Пароль = textBox2.Text;
                var b = db.Авторизация.FirstOrDefault(aa => aa.Логин == textBox1.Text);
                if(b ==null)
                {
                    db.Авторизация.Add(a);
                    db.SaveChanges();
                    MessageBox.Show("Вы успешно прошли регистрацию");
                }
                else
                {
                    MessageBox.Show("Такой логин уже существует");
                }
            }
        }
    }
}
