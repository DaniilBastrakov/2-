﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Бастраков
{
    public partial class Добавление_клиента : Form
    {
        public Добавление_клиента()
        {
            InitializeComponent();
        }

        private void Добавление_клиента_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Клиент клиент = new Клиент
            {

                Фамилия = textBox2.Text,
                Имя = textBox3.Text,
                Отчество = textBox4.Text,
                Номер_телефона = textBox5.Text,
                Электронная_почта = textBox6.Text,
                Логин = textBox7.Text,
                Недвижимость = textBox8.Text,
            };
             using (var db = new Агентство_недвижемостиEntities())
            {
                var resultsearch = db.Клиент.FirstOrDefault(item => item.Фамилия == textBox2.Text);

                if (resultsearch != null)
                {
                    db.Клиент.Add(resultsearch);
                    db.SaveChanges();
                    MessageBox.Show("Вы успешно добавили клиента");
                }
                else
                {
                    MessageBox.Show("Такой клиент уже добавлен");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Список_клиентов список_Клиентов = new Список_клиентов();
            список_Клиентов.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Клиент клиент = new Клиент
            {

                Фамилия = textBox2.Text,
                Имя = textBox3.Text,
                Отчество = textBox4.Text,
                Номер_телефона = textBox5.Text,
                Электронная_почта = textBox6.Text,
                Логин = textBox7.Text,
                Недвижимость = textBox8.Text,
            };
            using (var db = new Агентство_недвижемостиEntities())
            {
                var resultsearch = db.Клиент.FirstOrDefault(item => item.Фамилия == textBox2.Text);

                if (resultsearch != null)
                {
                    db.Клиент.Remove(resultsearch);
                    db.SaveChanges();
                    MessageBox.Show("Вы успешно добавили клиента");
                }
                else
                {
                    MessageBox.Show("Такой клиент уже добавлен");
                }
            }
        }
    }
}
